package com.example.harmeetsingh;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class reviewAdapter extends RecyclerView.Adapter<reviewAdapter.ViewHolder>{
    private List<modelForReviews> listItems;
    private Context context;
    String myString;

    public reviewAdapter(List<modelForReviews> listItems, Context context) {
        this.listItems = listItems;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View va= LayoutInflater.from(parent.getContext())
                .inflate(R.layout.revcardfile,parent,false);
        return new ViewHolder(va,context,(ArrayList<modelForReviews>)listItems);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final modelForReviews listItem=listItems.get(position);

        holder.timeShime.setText(listItem.getTime());
        holder.nameAuthor.setText(listItem.getNameAuthor());
        holder.rate.setText(listItem.getRate());
        holder.revi.setText(listItem.getReviewItself());
        Picasso.with(context)
                .load(listItem.getImgRev())
                .into(holder.imageRev);
    }
    @Override
//    public int getItemCount() {
//        return listItems.size();
//    }
    public int getItemCount() { return listItems == null ? 0 : listItems.size(); }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        public ImageView imageRev;
        public TextView nameAuthor;
        public TextView rate;
        public TextView timeShime;
        public TextView revi;
        public LinearLayout linearLayout;
        ArrayList<modelForReviews>recVArrayList=new ArrayList<modelForReviews>();
        Context context;
        public ViewHolder(View itemView, Context context, ArrayList<modelForReviews> recVArrayList) {
            super(itemView);
            this.recVArrayList=recVArrayList;
            this.context=context;
            itemView.setOnClickListener(this);
            imageRev=(ImageView) itemView.findViewById(R.id.iconssss);
            nameAuthor=(TextView) itemView.findViewById(R.id.author);
            rate=(TextView) itemView.findViewById(R.id.authrating);
            timeShime=(TextView) itemView.findViewById(R.id.time);
            revi=(TextView) itemView.findViewById(R.id.authorrev);
        }
        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            modelForReviews newObj = this.recVArrayList.get(position);
        }

    }
}
